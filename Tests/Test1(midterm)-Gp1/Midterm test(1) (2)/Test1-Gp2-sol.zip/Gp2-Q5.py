def evalReal(s):
    """
    Input: s is a string that contains a real number, e.g., s = "12.34".
    s must contain the radix point.
    Output: return the real number.
    """
    result = 0.
    posRadixPt = s.find(".")
    
    for i in range(posRadixPt):
        result = result + 10**(posRadixPt-i-1)*int(s[i])

    for i in range(posRadixPt+1,len(s)):
        result = result + 10**(-(i-posRadixPt))*int(s[i])

    return result

"""
print(".0 contains the value of", evalReal(".0"))
print("0. contains the value of", evalReal("0."))
print("1.0 contains the value of", evalReal("1.0"))
print("10. contains the value of", evalReal("10."))
print("12.345 contains the value of", evalReal("12.345"))
print("0.12345 contains the value of", evalReal("0.12345"))
"""
print(".0:", evalReal(".0"))
print("0.:", evalReal("0."))
print("1.0:", evalReal("1.0"))
print("10.:", evalReal("10."))
print("12.345:", evalReal("12.345"))
print("0.12345:", evalReal("0.12345"))


    
