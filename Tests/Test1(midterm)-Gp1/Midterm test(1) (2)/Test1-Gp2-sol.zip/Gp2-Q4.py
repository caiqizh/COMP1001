def testPrime(n):
    """
    Input: n is a positive integer greater than 1.
    Output: return true if n is a prime; otherwise, return false.
    """
    for i in range(2,n//2+1):
        if n % i == 0:
            return False

    return True

"""
print("2 is prime? ",testPrime(2))
print("4 is prime? ",testPrime(4))
print("11 is prime? ",testPrime(11))
print("121 is prime? ",testPrime(121))
print("3679 is prime? ",testPrime(3679))
print("38515076837129 is prime? ",testPrime(38515076837129))
"""
print(testPrime(2))
print(testPrime(4))
print(testPrime(11))
print(testPrime(121))
print(testPrime(3679))
print(testPrime(38515076837129))
